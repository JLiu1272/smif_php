<?php

	// Create connection
	$con=mysqli_connect("localhost","root","root","fridge_items");
	$mysqli = new mysqli("localhost","root", "root", "fridge_items");

	

?>

